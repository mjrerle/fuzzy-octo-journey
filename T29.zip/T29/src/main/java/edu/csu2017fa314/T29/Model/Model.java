package edu.csu2017fa314.T29.Model;
public class Model
{
   private int[] numbers;

   public Model () 
   {
      numbers = new int[] {0, 1, 2, 3, 4, 5};
   }

   public int[] getNumbers() 
   {
      return numbers;
   }

}
