**_Name_**: *Trey Yu*
**_Personality Type_**: *ISFJ*
**_Teamwork Questionnaire_**:
```
1) It is​ ​best​ ​to​ ​reach​ ​me​ ​by​ ​text​ ​and​ ​email.​ ​I​ ​will​ ​respond​ ​anytime​ ​when​ ​I​ ​am​ ​not​ ​in​ ​class
and​ ​before​ ​midnight​ ​on​ ​most​ ​days.
2) I​ ​expect​ ​my​ ​team​ ​will​ ​excel​ ​at​ ​communication​ ​and​ ​contribute​ ​their​ ​fair​ ​amount​ ​of​ ​work,
while​ ​reaching​ ​out/helping​ ​each​ ​out​ ​when​ ​needed
3) My​ ​personal​ ​goals​ ​is​ ​to​ ​ensure​ ​that​ ​I​ ​contribute​ ​my​ ​fair​ ​amount​ ​and​ ​take​ ​on​ ​any​ ​roles​ ​to
ensure​ ​an​ ​efficient​ ​work​ ​habit
4) I​ ​strongly​ ​desire​ ​to​ ​become​ ​a​ ​better​ ​student​ ​with​ ​better​ ​grades,​ ​and​ ​thus​ ​will​ ​be​ ​less
lenient​ ​on​ ​getting​ ​poor​ ​grades
5) As​ ​I​ ​would​ ​be​ ​on​ ​wanting​ ​to​ ​get​ ​an​ ​“A”,​ ​I​ ​would​ ​try​ ​to​ ​convince​ ​that​ ​the​ ​better​ ​grade​ ​will
better​ ​for​ ​all​ ​of​ ​us.​ ​However,​ ​if​ ​obtaining​ ​a​ ​B​ ​is​ ​absolutely​ ​needed,​ ​I​ ​will​ ​try​ ​to
accommodate
6) I​ ​believe​ ​that​ ​is​ ​nearly​ ​impossible​ ​for​ ​every​ ​team​ ​member​ ​to​ ​commit​ ​the​ ​same​ ​amount​ ​of
work,​ ​ ​but​ ​the​ ​effort​ ​must​ ​be​ ​there​ ​from​ ​each​ ​member.​ ​Thus,​ ​I​ ​am​ ​okay​ ​with​ ​some
students​ ​to​ ​do​ ​less​ ​work​ ​as​ ​long​ ​as​ ​it​ ​is​ ​not​ ​by​ ​a​ ​large​ ​margin
7) I​ ​believe​ ​that​ ​5​ ​hours​ ​a​ ​week​ ​should​ ​suffice
8) I​ ​will​ ​assess​ ​what​ ​each​ ​team​ ​member​ ​strong​ ​points​ ​are,​ ​and​ ​coordinate​ ​effort​ ​by
supporting​ ​those​ ​specific​ ​team​ ​member​ ​when​ ​they​ ​take​ ​lead​ ​on​ ​that​ ​specific​ ​task​ ​they
excel​ ​at
9) I​ ​will​ ​reach​ ​out​ ​to​ ​them​ ​the​ ​first​ ​time,​ ​give​ ​a​ ​warning​ ​the​ ​second​ ​time,​ ​and​ ​then​ ​go​ ​to​ ​the
professor​ ​on​ ​third​ ​time.
10) ​ ​We​ ​must​ ​try​ ​to​ ​understand​ ​each​ ​other​ ​and​ ​their​ ​point​ ​of​ ​view,​ ​and​ ​then​ ​find​ ​a​ ​good
comprises​ ​in​ ​between​ ​what​ ​is​ ​and​ ​is​ ​not​ ​good​ ​quality.
11) Communicating​ ​with​ ​individual​ ​member​ ​about​ ​what​ ​is​ ​an​ ​optimal​ ​work​ ​habit​ ​is,​ ​and​ ​try​ ​to
encourage​ ​that​ ​behavior
12) I​ ​do​ ​believe​ ​we​ ​should​ ​meet​ ​a​ ​couple​ ​times​ ​throughout​ ​the​ ​semester​ ​to​ ​ensure​ ​delivery
and​ ​sprints​ ​are​ ​completed​ ​adequately,​ ​but​ ​do​ ​not​ ​need​ ​a​ ​weekly​ ​meeting.
13) ​ ​As​ ​mentioned​ ​before,​ ​whenever​ ​necessary.
14) I​ ​believe​ ​those​ ​who​ ​are​ ​most​ ​informed​ ​on​ ​the​ ​issue​ ​should​ ​be​ ​part​ ​of​ ​the​ ​approval​ ​of
every​ ​decision,​ ​and​ ​we​ ​should​ ​always​ ​have​ ​at​ ​least​ ​two​ ​people​ ​approving​ ​anything.
15) ​ ​Listen​ ​to​ ​what​ ​that​ ​individual​ ​is​ ​trying​ ​to​ ​say​ ​and​ ​take​ ​it​ ​into​ ​serious​ ​consideration,​ ​and
then​ ​try​ ​to​ ​come​ ​to​ ​an​ ​optimal​ ​compromise.
16) Explain​ ​the​ ​situation​ ​to​ ​the​ ​individual​ ​and​ ​explain​ ​that​ ​more​ ​than​ ​one​ ​mind​ ​on​ ​any​ ​issue
is​ ​better​ ​than​ ​just​ ​one
17) Explain​ ​the​ ​situation​ ​to​ ​the​ ​other​ ​group​ ​members,​ ​and​ ​try​ ​to​ ​find​ ​an​ ​optimal​ ​compromise
