* Elliott Roberts
* Personality Type: INFP
* Questionare:
1. Is it generally easier to reach you by text, email, vmail or something else? What hours? 
  * Text is the best way to reach me at any time between 8am to 9pm, otherwise I check my email regularly throughout the day. 
2. What are your expectations about what your team will accomplish this semester? 
  * Collaborate with each other while communicating issues and solutions to the problems in our assignments. 
3. What are your personal goals for improving your teamwork and communication skills this semester? 
  * Learn about using tools cohesively with teammates and working productively with a team through communication. 
4. What kinds of obstacles might you encounter in trying to reach both your team and personal goals? 
  * Trips out of town may be an issue such as during travel team members may be unreachable for hours or even days. 
5. What happens if some people on the team want to get an “A” while others think a “B” will be acceptable? 
  * A discussion should take place about time and effort, the group needs to accomplish its goals for the project. 
6. Is it acceptable for some team members to do more work on the assignment in order to get an “A”? 
  * No, each team member should put in the same amount of work. 
7. How much time per week do you anticipate it will take to make the project successful? 
  * 10-20 hours. 
8. How will you decide who should do what on the project and activities? 
  * The group should have a discussion prior to beginning the project. 
9. What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)? 
  * The group should talk with them about it and let the professor know about the situation.
10. What happens if people have different opinions on the quality of the work? 
  * Some compromises will need to be made.
11. How will you deal with different work habits of team members?
  * Set up meetings so that the group knows exactly where each members work is, while encouraging others to keep up with the team.
12. Do you want to have a standing meeting time outside of class?
  * Yes.
13. How often do you think the team will need to meet outside of class?
  * Twice a week.
14. Will you need approval of every team member before making a decision?
  * No, just one other member.
15. What will you do if every team member except one agrees on something?
  * Discuss it but go with the majority vote in most cases.
16. What will you do if one person seems to be dominating the team process?
  * Talk with the person in question along with the rest of the team about it.
17. What will you do if you feel most of the facilitation responsibilities are falling on you?
  * Ask for help.
