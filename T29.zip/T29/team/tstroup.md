**Tim Stroup**

**Personality Type: INTP**

* Is it generally easier to reach you by text, email, vmail or something else?  What hours?
    * It is easiest to reach me by text and then email and  then facebook message anytime.

* What are your expectations about what your team will accomplish this semester?
    * We are going to build the greatest application that we can!

* What are your personal goals for improving your teamwork and communication skills this semester?
    * I would like to improve my group speaking skills 

* What kinds of obstacles might you encounter in trying to reach both your team and personal goals?
    * People that suddenly have work or that have other class work

* What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?
    * I think that the team needs to get on the same page and strive to do our best

* Is it acceptable for some team members to do more work on the assignment in order to get an “A”?
    * I don’t think that some should do less work and that everyone should want to do their best work

* How much time per week do you anticipate it will take to make the project successful?
    * About 6 hours as recommended by the cs department

* How will you decide who should do what on the project and activities?
    * I think that we should have a group meeting and discuss by either having a vote or asking the team what they prefer to work on.

* What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?
    * First the team will have a meeting and discuss what went wrong. If it were to happen again we would schedule a meeting with the professor.

* What happens if people have different opinions on the quality of the work?
    * Then we will have a discussion on why they think that way and try to get a clear view.

* How will you deal with different work habits of team members?
    * Try to work as best we can as a team. But some people work differently. If it hurts the team we will have a discussion.

* Do you want to have a standing meeting time outside of class?
    * I think that would be a good idea in order to keep on top of our work.

* How often do you think the team will need to meet outside of class?
    * I think that two times a week might be a good idea but at least once.

* Will you need approval of every team member before making a decision?
    * I think that would be best but if it is not possible as many as we can.

* What will you do if every team member except one agrees on something?
    * Have a discussion with them as a team and take into account their opinions. In the end though we will have to move on.

* What will you do if one person seems to be dominating the team process?
    * Have a talk about working as a team more. Meet with the team and have a discussion if it continues.

* What will you do if you feel most of the facilitation responsibilities are falling on you?
    * Meet with the team and share with them my feelings. If it does not stop then ask to have a meeting with the professor. 

