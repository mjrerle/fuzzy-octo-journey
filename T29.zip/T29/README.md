# DTR-29 - SPB

* Elliott Roberts, ejrober, ejrober
* Matt Erle, mjrerle, mjrerle
* Tim Stroup, tstroup, TimStroup, l33t
* Trey Yu, treyyu28, TreyYu168, 天暢

Sprint # | Model - Data | Model - Itinerary | View - Server | View - Client
-------- | ------------ | ----------------- | ------------- | -------------
1 | Elliott Roberts | Trey Yu | Matt Erle | Tim Stroup
2 | | | |
3 | | | | 
4 | | | |
5 | | | |
